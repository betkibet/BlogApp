package com.controllers;

import com.dao.PostsDao;
import com.models.Post;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.jws.WebParam;
import java.util.List;

@Controller
@RequestMapping("/posts")
public class PostsController {
    @Autowired
    private PostsDao p;

    @RequestMapping(method = RequestMethod.GET)
    public String landingPage(Model model){
        List<Post> posts = p.readAll();
        model.addAttribute("posts", posts);
        System.out.println(posts.toString());
        return "index";
    }

    @RequestMapping(method = RequestMethod.POST)
    public String savePost(Model model,@ModelAttribute("post")Post post){
       p.create(post);
       return "Success";
    }
}
