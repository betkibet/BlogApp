package com.dao;

import com.models.Comment;
import com.models.Post;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
@Transactional

public class PostsDaoImpl implements PostsDao {

    @PersistenceContext

    private EntityManager e;

    public void create(Post post) {

        e.persist(post);
    }

    public void update(Post post) {

    }

    public void delete(Post post) {

    }

    public Post readOne(Integer id) {
        Post p = e.find(Post.class, id);
        return p;
    }

    public List<Post> readAll() {

        List<Post> posts = e.createQuery("Select a from Post a", Post.class).getResultList();
        return posts;
    }
}
