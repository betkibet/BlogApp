package com.dao;

import com.models.Comment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.sql.Statement;
import java.util.List;


@Repository
@Transactional

public class CommentsDaoImpl implements CommentsDao{

    @PersistenceContext
    private EntityManager e;

    public void create(Comment comment) {
        //String sql = "insert into comments (author, comment, post_id) values ('"+comment.getAuthor()+"','"+comment.getComment()+"', '"+comment.getPost_id()+"')";
        //e.persist(comment);

        System.out.println(comment.toString());

    }

    public void update(Comment comment) {
        //String sql = "update comments set author ='"+comment.getAuthor()+"', comment ='"+comment.getComment()+"' where id  = '"+comment.getId()+"'";
    }

    public void delete(Comment comment) {
        //String sql = "delete from comments where id ='"+comment.getId()+"'";
    }

    public Comment readOne(Comment comment) {
        //String sql = "Select * from comments where id ='"+comment.getId()+"'";
        Comment c = e.find(Comment.class, comment);
        return c;
    }

    public List<Comment> readAll() {
        //String sql = "select * from comments";
        List<Comment> comments = e.createQuery("Select a from Comment a", Comment.class).getResultList();
        return comments;
    }
}

