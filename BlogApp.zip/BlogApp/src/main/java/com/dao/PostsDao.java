package com.dao;

import com.models.Post;

import java.util.List;

public interface PostsDao {
    void create(Post post);
    void update(Post post);
    void delete(Post post);
    Post readOne(Integer id);
    List<Post> readAll();
}
