package com.dao;

import com.models.Post;

import java.util.List;

public interface PostsDao {
    void create(Post post);
    void update(Post post);
    void delete(Post post);
    Post readOne(Post post);
    List<Post> readAll();
}
