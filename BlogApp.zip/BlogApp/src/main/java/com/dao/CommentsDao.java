package com.dao;

import com.models.Comment;

import java.util.List;

public interface CommentsDao {
    void create(Comment comment);
    void update(Comment comment);
    void delete(Comment comment);
    Comment readOne(Comment comment);
    List<Comment> readAll();
    /*List<Comment> readByPostId(int post_id);*/
}
