package com.dao;

public class RolesDaoImpl {
}
