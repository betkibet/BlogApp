package com.dao;

import com.models.Event;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
@Transactional

public class EventsDaoImpl implements EventsDao{

    @PersistenceContext
    private EntityManager ev;

    @Override
    public void create(Event e) {

        ev.persist(e);
    }

    @Override
    public void update(Event e) {

    }

    @Override
    public void delete(int id) {

    }

    @Override
    public Event readOne(int id) {
        Event event = ev.find(Event.class, id);
        return event;
    }

    @Override
    public List<Event> readAll() {
        List<Event> events = ev.createQuery("Select a from Event a", Event.class).getResultList();
        return events;
    }
}
