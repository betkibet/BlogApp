package com.dao;

import com.models.Role;

import java.util.List;

public interface RolesDao {

    void create(Role r);
    void update(Role r);
    void delete(int id);
    Role readOne(int id);
    List<Role> readAll();
    List<Role> readByUserId(int id);

}
