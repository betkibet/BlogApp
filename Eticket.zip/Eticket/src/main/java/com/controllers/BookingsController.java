package com.controllers;

import com.dao.BookingsDao;
import com.models.Booking;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller

public class BookingsController {
    @Autowired
    private BookingsDao books;

    @RequestMapping(value = "/bookings", method = RequestMethod.GET)
    public String createBooking(Model model){
        Booking bs = new Booking();
        model.addAttribute("booking", bs);
        return "events/book_event";
    }


}
