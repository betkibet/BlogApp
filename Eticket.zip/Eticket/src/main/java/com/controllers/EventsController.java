package com.controllers;

import com.dao.EventsDao;
import com.models.Event;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class EventsController {

    @Autowired
    private EventsDao ev;

    @RequestMapping(value = "/new_event", method = RequestMethod.GET)
    public String createEvent(Model model){
        Event bs = new Event();
        model.addAttribute("event", bs);
        return "events/new_event";
    }

    @RequestMapping(value = "/saveEvent", method = RequestMethod.POST)
    public String saveComment(Model model, @ModelAttribute("event")Event comment){
        ev.create(comment);

        List<Event> events = ev.readAll();
        model.addAttribute("event",events);
        return "events/all_events";
    }
    @RequestMapping(value ="/events", method = RequestMethod.GET)
    public String indexPage(Model model){
        List<Event> events = ev.readAll();
        model.addAttribute("events",events);
        return "events/all_events";
    }
}
